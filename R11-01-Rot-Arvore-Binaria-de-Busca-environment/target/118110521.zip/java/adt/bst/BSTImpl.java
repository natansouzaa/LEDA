package adt.bst;

import adt.bt.BTNode;

import java.util.ArrayList;
import java.util.List;

public class BSTImpl<T extends Comparable<T>> implements BST<T> {

	protected BSTNode<T> root;

	public BSTImpl() {
		root = new BSTNode<T>();
	}

	public BSTNode<T> getRoot() {
		return this.root;
	}

	@Override
	public boolean isEmpty() {
		return root.isEmpty();
	}

	@Override
	public int height() {
		return heightAux(this.root);
	}

	private int heightAux(BSTNode node){
		if (node.isEmpty()){
			return -1;
		} else {
			return 1 + Math.max(heightAux((BSTNode) node.getLeft()), heightAux((BSTNode) node.getRight()));
		}
	}

	@Override
	public BSTNode<T> search(T element) {
		return searchAux(this.root, element);
	}

	private BSTNode<T>  searchAux(BSTNode node, T element){
		if (node.isEmpty() || element.compareTo((T) node.getData()) == 0){
			return node;
		} else {
			if (element.compareTo((T) node.getData()) < 0){
				return searchAux((BSTNode) node.getLeft(), element);
			} else if (element.compareTo((T) node.getData()) > 0){
				return searchAux((BSTNode) node.getRight(), element);
			} else {
				return node;
			}
		}
	}

	@Override
	public void insert(T element) {
		insertAux(this.root, element, new BSTNode<>());
	}

	private void insertAux(BSTNode node, T element, BSTNode parent){
		if (node.isEmpty()){
			node.setData(element);
			node.setLeft(new BSTNode());
			node.setRight(new BSTNode());
			node.setParent(parent);
		} else {
			if (element.compareTo((T) node.getData()) < 0){
				insertAux((BSTNode) node.getLeft(), element, node);
			} else if (element.compareTo((T) node.getData()) > 0){
				insertAux((BSTNode) node.getRight(), element, node);
			}
		}
	}

	@Override
	public BSTNode<T> maximum() {
		return maximumAux(this.root);
	}

	private BSTNode<T> maximumAux(BTNode node){
		BTNode aux = node;
		if (!node.isEmpty()){
			while (!aux.getRight().isEmpty()){
				aux = aux.getRight();
			}
			return (BSTNode<T>) aux;
		}
		return null;
	}

	@Override
	public BSTNode<T> minimum() {
		return minimumAux(this.root);
	}

	private BSTNode<T> minimumAux(BTNode<T> node) {
		BTNode aux = node;
		if (!node.isEmpty()){
			while (!aux.getLeft().isEmpty()){
				aux = aux.getLeft();
			}
			return (BSTNode<T>) aux;
		}
		return null;
	}
	@Override
	public BSTNode<T> sucessor(T element) {
		BSTNode<T> node = search(element);
		if (node.isEmpty()) {
			return null;
		} else if (!node.getRight().isEmpty()) {
			return this.minimumAux(node.getRight());
		} else if (node.getParent().getLeft() == node) {
			return (BSTNode<T>) node.getParent();
		}
		while (!node.isEmpty() && this.isRightChild(node, (BSTNode<T>) node.getParent())) {
			node = (BSTNode<T>) node.getParent();
		}
		return (BSTNode<T>) node.getParent();
	}

	@Override
	public BSTNode<T> predecessor(T element) {
		BSTNode<T> node = this.search(element);
		if (node.isEmpty()) {
			return null;
		} else if (!node.getLeft().isEmpty()) {
			return this.maximumAux(node.getLeft());
		} else if (node.getParent().getRight() == node) {
			return (BSTNode<T>) node.getParent();
		}
		while (!node.isEmpty() && this.isLeftChild(node, (BSTNode) node.getParent())) {
			node = (BSTNode<T>) node.getParent();
		}
		if (node == this.root) {
			return null;
		}
		return (BSTNode<T>) node.getParent();
	}

	@Override
	public void remove(T element) {
		BSTNode<T> node = this.search(element);
		remove(node);
	}

	private void remove(BSTNode<T> node) {
		if (node == null || node.isEmpty()) {
			return;
		}
		if (node.isLeaf()) {
			if (node == this.root) {
				this.root = new BSTNode<T>();
			} else if (isLeftChild(node, node.getParent())) {
				node.getParent().setLeft(new BSTNode<T>());
			} else {
				node.getParent().setRight(new BSTNode<T>());
			}
		} else if (hasOneRightChild(node)) {
			if (node == this.root) {
				this.root = (BSTNode<T>) node.getRight();
			} else {
				if (isLeftChild(node, node.getParent())) {
					node.getParent().setLeft(node.getRight());
				} else {
					node.getParent().setRight(node.getRight());
				}
				node.getRight().setParent(node.getParent());
			}
		} else if (hasOneLeftChild(node)) {
			if (node == this.root) {
				this.root = (BSTNode<T>) node.getLeft();
			} else {
				if (isLeftChild(node, node.getParent())) {
					node.getParent().setLeft(node.getLeft());
				} else {
					node.getParent().setRight(node.getLeft());
				}
				node.getLeft().setParent(node.getParent());
			}
		} else {
			BSTNode<T> auxNode = this.sucessor(node.getData());
			if (auxNode == null) {
				auxNode = this.predecessor(node.getData());
			}
			T aux = node.getData();
			node.setData(auxNode.getData());
			auxNode.setData(aux);
			this.remove(auxNode);
		}
	}

	private boolean isLeftChild(BSTNode<T> node, BTNode<T> parent) {
		if (node == null || node.isEmpty()) {
			return false;
		} else {
			return parent.getLeft() == node;
		}
	}

	private boolean isRightChild(BSTNode<T> node, BTNode<T> parent) {
		if (node == null || node.isEmpty()) {
			return false;
		} else {
			return parent.getRight() == node;
		}
	}

	protected boolean hasOneLeftChild(BSTNode<T> node) {
		if (node.isEmpty() || node == null) {
			return false;
		} else {
			return !node.getLeft().isEmpty() && node.getRight().isEmpty();
		}
	}

	protected boolean hasOneRightChild(BSTNode<T> node) {
		if (node.isEmpty() || node == null) {
			return false;
		} else {
			return !node.getRight().isEmpty() && node.getLeft().isEmpty();
		}
	}

	@Override
	public T[] preOrder() {
		List<T> result = new ArrayList<>(this.size());
		preOrder(result, this.root);
		return result.toArray((T[]) new Comparable[this.size()]);
	}

	private void preOrder(List<T> lista, BTNode<T> node) {
		if (!node.isEmpty()) {
			lista.add(node.getData());
			preOrder(lista, node.getLeft());
			preOrder(lista, node.getRight());
		}
	}

	@Override
	public T[] order() {
		List<T> result = new ArrayList<>(this.size());
		order(result, this.root);
		return result.toArray((T[]) new Comparable[this.size()]);
	}

	private void order(List<T> lista, BTNode<T> node) {
		if (!node.isEmpty()) {
			order(lista, node.getLeft());
			lista.add(node.getData());
			order(lista, node.getRight());
		}
	}

	@Override
	public T[] postOrder() {
		List<T> result = new ArrayList<>(this.size());
		postOrder(result, this.root);
		return result.toArray((T[]) new Comparable[this.size()]);
	}

	private void postOrder(List<T> lista, BTNode<T> node) {
		if (!node.isEmpty()) {
			postOrder(lista, node.getLeft());
			postOrder(lista, node.getRight());
			lista.add(node.getData());
		}
	}

	/**
	 * This method is already implemented using recursion. You must understand
	 * how it work and use similar idea with the other methods.
	 */
	@Override
	public int size() {
		return size(root);
	}

	private int size(BSTNode<T> node) {
		int result = 0;
		// base case means doing nothing (return 0)
		if (!node.isEmpty()) { // indusctive case
			result = 1 + size((BSTNode<T>) node.getLeft())
					+ size((BSTNode<T>) node.getRight());
		}
		return result;
	}

}
