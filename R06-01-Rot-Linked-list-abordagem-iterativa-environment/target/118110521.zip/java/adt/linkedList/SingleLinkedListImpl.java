package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T>{

	protected SingleLinkedListNode<T> head;

	public SingleLinkedListImpl(){
		this.head = new SingleLinkedListNode<T>();
	}

	@Override
	public boolean isEmpty() {
		return this.head.isNIL();
	}

	@Override
	public int size() {
		int size = 0;
		SingleLinkedListNode auxHead = this.head;
		while (!auxHead.isNIL()){
			size++;
			auxHead = auxHead.next;
		}
		return size;
	}

	@Override
	public T search(Object element) {
		SingleLinkedListNode<T> auxHead = this.head;
		while (!auxHead.isNIL() && auxHead.data != element){
			auxHead = auxHead.next;
		}
		return auxHead.data;
	}

	@Override
	public void insert(Object element) {
		SingleLinkedListNode auxHead = this.head;
		if (this.head.isNIL()){
			SingleLinkedListNode newHead = new SingleLinkedListNode(element, this.head);
			this.head = newHead;
		} else {
			while (!auxHead.next.isNIL()){
				auxHead = auxHead.next;
			}
			SingleLinkedListNode newNode = new SingleLinkedListNode(element, auxHead.next);
			auxHead.next = newNode;
		}
	}

	@Override
	public void remove(Object element) {
		if (this.head.data == element){
			this.head = this.head.next;
		} else {
			SingleLinkedListNode auxHead = this.head;
			SingleLinkedListNode previous = this.head;
			while (!auxHead.isNIL() && auxHead.data != element){
				previous = auxHead;
				auxHead = auxHead.next;
			}
			if (!auxHead.isNIL()){
				previous.next = auxHead.next;
			}
		}
	}

	@Override
	public T[] toArray() {
		T[] result = (T[]) new Object[size()];
		SingleLinkedListNode auxHead = this.head;
		int count = 0;
		while (!auxHead.isNIL()){
			result[count] = (T) auxHead.data;
			auxHead = auxHead.next;
			count++;
		}
		return result;
	}
}