package adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T> implements
		DoubleLinkedList<T> {

	protected DoubleLinkedListNode<T> last;

	public DoubleLinkedListImpl() {
		head = new DoubleLinkedListNode<T>();
		last = (DoubleLinkedListNode<T>) head;
	}

	@Override
	public void insertFirst(T element) {
		DoubleLinkedListNode<T> newHead = new DoubleLinkedListNode<T>(element, new DoubleLinkedListNode<T>(), new DoubleLinkedListNode<T>());
		newHead.next = this.head;
		((DoubleLinkedListNode<T>) this.head).previous = newHead;
		if (this.head.isNIL()){
			this.last = newHead;
		}
		this.head = newHead;
	}

	@Override
	public void insert(Object element) {
		if (element != null) {

			if (this.isEmpty()) {

				this.head.setData((T) element);
				this.head.setNext(new DoubleLinkedListNode<T>());
				this.last.setNext(new DoubleLinkedListNode<T>());
				this.last.setPrevious(new DoubleLinkedListNode<T>());
				((DoubleLinkedListNode<T>) this.head).setPrevious(new DoubleLinkedListNode<T>());

			} else {
				DoubleLinkedListNode<T> aux = (DoubleLinkedListNode<T>) this.head;

				while (!aux.getNext().isNIL()) {
					aux = (DoubleLinkedListNode<T>) aux.getNext();
				}

				((DoubleLinkedListNode<T>) aux.getNext()).setPrevious(aux);
				this.last = (DoubleLinkedListNode<T>) aux.getNext();
				aux.getNext().setData((T) element);
				aux.getNext().setNext(new DoubleLinkedListNode<T>());
			}
		}
	}

	@Override
	public void removeFirst() {
		if (!this.head.isNIL()){
			this.head = this.head.next;
			if (head.isNIL()){
				this.last = (DoubleLinkedListNode<T>) this.head;
			}
			((DoubleLinkedListNode<T>) this.head).previous = new DoubleLinkedListNode<T>();
		}
	}

	@Override
	public void removeLast() {
		if (!this.last.isNIL()){
			this.last = this.last.previous;
			if (this.last.isNIL()){
				this.head = this.last;
			}
			this.last.next = new DoubleLinkedListNode<T>();
		}
	}

	public DoubleLinkedListNode<T> getLast() {
		return last;
	}

	public void setLast(DoubleLinkedListNode<T> last) {
		this.last = last;
	}

}